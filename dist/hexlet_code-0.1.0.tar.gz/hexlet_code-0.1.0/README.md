### Hexlet tests and linter status:
[![Actions Status](https://github.com/fyodor91/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/fyodor91/python-project-50/actions)

![example workflow](https://github.com/fyodor91/python-project-50/actions/workflows/my_workflow.yml/badge.svg)

[![Test Coverage](https://api.codeclimate.com/v1/badges/3157b4986130a9103b59/test_coverage)](https://codeclimate.com/github/fyodor91/python-project-50/test_coverage)

[![Maintainability](https://api.codeclimate.com/v1/badges/3157b4986130a9103b59/maintainability)](https://codeclimate.com/github/fyodor91/python-project-50/maintainability)

[gendiff](https://asciinema.org/a/596685)
